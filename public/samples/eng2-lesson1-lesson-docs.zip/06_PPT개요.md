# PPT 개요 — 중2 영어 Lesson 1 "Off to a Good Start" (6차시 전체)

**TeachFlow · PPT Workflow — PHASE 4 산출물**
상류 제약: 04·05_수업지도안에 엄격히 근거. 수업 흐름 재설계 없음.
공통 Style: 0번 크림 플랫 교육풍(style-library 기본값). 1376×768 AI 전면 이미지 + 긴 원문 페이지는 하이브리드(빈 카드 + 편집 가능 텍스트).

---

## 1차시 — 듣기 (12p)

| Slide | 페이지 제목 | 학생에게 보이는 내용 | 교재 원문/예문 | 학생 과제 | Teacher Note | Style Tip |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | Lesson 1 Off to a Good Start | 단원명·차시(1/6 듣기)·오늘의 목표 1줄 | — | — | 수업 시작 전 화면에 띄워 둠 | 새 학기 아침 교실 일러스트 |
| 2 | Warm Up: My Goal This Year | "올해 이루고 싶은 목표는?" + 요소 보기(계획·노력·충고) | p.10 Warm Up 지시문 요지 | 목표 1개 떠올리고 중요한 요소 말하기 | 한국어 허용, 영어 단어 받아 적기 | 목표 화살·과녁 그림 |
| 3 | Plan Ahead | Listening/Speaking/Reading/Writing 4영역 미리보기 + 자기 점검 | p.10 Plan Ahead 표 | Lesson 1을 훑어보며 challenging 표시 | challenging 학습 계획 한마디 | 4칸 미리보기 카드 |
| 4 | Before You Listen: 두 계획표 | Weekly Planner A/B 나란히 — 민솔이의 표는 어느 쪽? | p.12 두 Weekly Planner 항목 | 차이 비교하고 예측 | 예측 답을 칠판에 메모 | 두 달력 카드 비교 |
| 5 | 1st Listening: 주제는? | "두 사람은 무엇에 관해 이야기하나요?" + 보기 | Dialog 1·2 (Script 1.1·1.2) | 대본 없이 듣고 주제 판단 | 주제만 묻는다 | 귀·음표 일러스트 |
| 6 | 2nd Listening: +Questions | ① Why does Minsol plan to make a schedule? She wants to ___ better. ② What advice does Minsu give? | p.13 +Question | 다시 듣고 빈칸·충고 완성 | 필요 시 부분 재생 | 질문 카드 2장 |
| 7 | All Ears: 억양 따라 하기 | 파란색 문장 2개 | "How would you achieve your goal?" / "I'd like to visit you this Saturday." | 듣고 억양 따라 하기 | 끊어 따라 하기 → 연속 | 음성 파형 그림 |
| 8 | 오늘의 표현 | I'm planning to ~ / You should ~ / Why don't you ~? | Dialog 속 표현 | 소리로 인식한 표현 확인 | 2차시 말하기 예고 | 표현 카드 3장 |
| 9 | Listen More: 전화의 이유는? | 만화 그림 — 종하가 할머니께 전화한 이유 추측 | p.13 Look and guess | 그림 보고 추측 | 추측은 듣기 전에만 | 전화하는 소년 만화풍 |
| 10 | Listen More: 듣고 완성 | 할 일: visit Grandma / plant some ___ + 준비물 보기 | p.13 Listen and complete/choose | 듣고 완성·선택 | 두 번 듣기 | 체크리스트 그림 |
| 11 | 오늘 들은 표현 돌아보기 | 표현 카드 3장 재제시 | — | 기억나는 표현 하나 말하기 | 카드를 가리며 회상 | 카드 뒤집기 |
| 12 | Next Time | 2차시 말하기 예고 — "직접 말해 봅시다" | — | — | — | 화살표 배너 |

## 2차시 — 말하기 (12p)

| Slide | 페이지 제목 | 학생에게 보이는 내용 | 교재 원문/예문 | 학생 과제 | Teacher Note | Style Tip |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | 2차시 말하기 + RapTime | RapTime 가사(What are you planning to do tonight? … / Why don't you do something cool? …) | p.14~15 RapTime | 랩 따라 하기 | 2회 반복, 박자 | 리듬 음표 배너 |
| 2 | Model Dialogue ① | 모범 대화: 만우절 계획 | "I'm planning to play a trick on my homeroom teacher." / "Nothing special. How about you?" | 묻는 말·답하는 말·바꿀 자리 찾기 | 바꿀 자리 색 표시 | 대화 말풍선 2개 |
| 3 | Sentence Frames | What are you planning to do ~? → I'm planning to ~ / I'd like to ~ | p.14 대화에서 추출 | 틀 익히기 | planning to + 동사 강조 | 문장 틀 카드 |
| 4 | Pair Work: 날짜 카드 | 날짜 카드 4개(on April Fool's Day / on Parents' Day / on ~'s birthday / this weekend) | p.14 Get ready | 카드 뽑고 묻고 답하기 | 동사구 예시 목록 함께 | 달력 카드 4장 |
| 5 | Model Dialogue ② | 모범 충고 대화 | "Why don't you take your baseball glove?" / "I think you should buy tickets first." | 충고 표현 2개 찾기 | 충고 vs 질문 구분 | 글러브·티켓 그림 |
| 6 | Advice Frames | Why don't you ~? / I think you should ~ | p.15 | 틀 익히기 | 명령이 아닌 제안 어조 | 표현 카드 2장 |
| 7 | Group Work: 소망 카드 | 인물 4명 소망(stronger/ballpark, more allowance, learn Chinese, make friends) | p.15 Get ready | 소망 듣고 충고하기 | 1인 1충고 | 인물 카드 4장 |
| 8 | Portfolio Step 1: 듣고 연결 | Nayeon·Junho·Hojin 목표-계획 연결판 | p.16 Script 1.5 | 듣고 연결 | 모범 발표의 재료 | 인물 3명 카드 |
| 9 | Model Presentation | 모범 발표문 구조(First, I'd like to ~ / To achieve this goal, I'm planning to ~ / The other goal is ~) | p.16 모범 발표문(10 km marathon) | 구조 3단 찾기 | 구조 색 표시 | 마라톤 그림 + 구조 도식 |
| 10 | Step 2: Plan Your Goals | 계획 표(목표 2개 × 실행 계획) | p.16 Step 2 | 표 채우기 | 표 먼저, 발표 나중 | 빈 표 카드 |
| 11 | Step 3: Present & Share | 발표 규칙(1분·표 보고 말하기) + 듣는 사람 과제(목표 하나 메모) | p.16 Step 3 | 1분 발표 | 3~4명 발표+짝 발표 | 마이크 그림 |
| 12 | Feedback & Wrap-up | 칭찬 틀(I liked your goal about ~.) + 다음 차시 예고 | — | 잘한 점 말해 주기 | 내용→언어 순 | 하트 카드 |

## 3차시 — 읽기① (13p)

| Slide | 페이지 제목 | 학생에게 보이는 내용 | 교재 원문/예문 | 학생 과제 | Teacher Note | Style Tip |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | 3차시 읽기① + Topic | "I want to change my eating habits." + 질문 | p.16 Topic | 바꾸고 싶은 것 말하기 | I want to change ~ 틀 | 거울 보는 학생 |
| 2 | 예측 ①: 제목 읽기 | 큰제목(Beginning a New School Year) + 소제목 6개 | p.16 Question Box 1·2 | 대상·목적·내용 예측 | 예측 틀(This text is for ~) | 돋보기 + 제목 |
| 3 | 예측 ②: Robbie의 배낭 | "Robbie bought a backpack which is big and light." | p.16 Question Box 3 | 배낭 특징 2개 말하기 | which는 5차시에 형태 | 배낭 그림 |
| 4 | Expressions | 색칠 표현 4개 + 문장 | "My room gets messy because of my pet. I have to clean it up every day. She sometimes drives me crazy, but we care for each other." | 그림·문맥으로 뜻 추측 | 뜻 보기(선택형) | 4개 아이콘 카드 |
| 5 | 도입부 읽기 | 도입 단락 원문 | "Beginning a new school year is stressful to many students. How can we get off to a good start? Teen Today asked Raccoon 97, a popular webtoon artist, for ideas." | 조용히 읽고 글의 대상 말하기 | 예측 확인 | 잡지 인터뷰 그림 |
| 6 | 1부 지도: Hard to Change | 소제목 3개(Your Messy Room / Your Family / Your Name on Your Teacher's List) | p.19 | 어떤 내용일지 짐작 | 정리표 미리 보기 | 3개 문 카드 |
| 7 | Your Messy Room | 해당 항목 원문 | "You clean it up. Then you bring new stuff into it, and it soon gets messy again. But don't worry. Your room is much cleaner than mine." | 왜 다시 어질러지는지 찾기 | 인과 표시 화살표 | 어질러진 방 일러스트 (하이브리드: 원문 텍스트 박스) |
| 8 | Your Family | 해당 항목 원문 | "There is always someone in your family who drives you crazy. … You just have to live together and care for each other." | who절이 꾸며 주는 명사 찾기 | drive me crazy 뉘앙스 | 가족 그림 (하이브리드) |
| 9 | Your Name on the List + Q1 | 해당 항목 원문 + Q1(T/F) | "If you are late or do not behave, your teacher will put your name on his or her list." / Q1 문장 | Q1 판단 + 근거 밑줄 | F의 근거(or do not behave) | 명단 클립보드 (하이브리드) |
| 10 | 정리표: Hard 3항목 | 표(무엇이/왜 어려운가) 3행 | p.19 정리 | 표 채우기 | 첫 행은 함께 | 3행 표 카드 |
| 11 | Language Focus | drive me crazy / care for each other가 쓴 문장 재제시 | p.19 Your Family | 뉘앙스 말하기 | 한국어 뉘앙스 OK | 표현 확대 카드 |
| 12 | 작가작업실의 고양이 | Sartre 인용 수수께끼 | "Life is C between B and D." | C가 무엇일지 짐작 | 4차시에 회수 예고 | 고양이 + 물음표 |
| 13 | Wrap-up: 2부 예측 | "바꾸기 쉬운 것은?" | 소제목(Things That Are Easy to Change) | 1개 예측 | 칠판에 적어 보존 | 반쪽 문 그림 |

## 4차시 — 읽기② (12p)

| Slide | 페이지 제목 | 학생에게 보이는 내용 | 교재 원문/예문 | 학생 과제 | Teacher Note | Style Tip |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | 4차시 읽기② + 복기 | 3차시 예측 목록 재제시 | — | 예측 확인 준비 | 지난 차시 칠판 사진 활용 | 되감기 화살표 |
| 2 | 2부 지도: Easy to Change | 소제목 3개(Your Underpants / Your Friends / Your Mind) | p.19~20 | 짐작 말하기 | 유머 예고 | 3개 문 카드 |
| 3 | Your Underpants | 해당 항목 원문 | "If you change them every day, your mom will not tell you one hundred and one times." | 유머 표현 찾기 | 과장(one hundred and one) | 양말·속옷 일러스트 (하이브리드) |
| 4 | Your Friends | 해당 항목 원문 | "If you add a new friend to the list, however, you will feel even better than before." | '바꾼다'의 진짜 뜻 찾기 | add 강조 | 친구 추가 그림 (하이브리드) |
| 5 | Your Mind + 결론 | 해당 항목 원문 + 결론 | "If you can change your mind, you can change your life." / "Focus on the things that are easy to change, and try to make today better than yesterday. Good luck!" | 글쓴이의 조언 한 문장 | 결론 문장 소리 내어 읽기 | 생각 풍선 (하이브리드) |
| 6 | Hard vs Easy | 두 표 나란히 + 조언 문장 틀(We should focus on ~) | p.19~20 | 대비 보고 조언 완성 | 3차시 표 재사용 | 좌우 대비 표 |
| 7 | 수수께끼 정답 | Sartre 인용 해설 | "Life is C between Birth and Death." → Answer: Choice | 의미 확인 | 선택의 힘 연결 | 고양이 + 정답 카드 |
| 8 | Top Plans for the Year | 설문 막대(72·41·28·26·19·14, 200명) + Q2 | p.20 설문 + "If you have more (books / friends / underpants), you will feel happier." | 1위 찾기 + Q2 답과 근거 | 본문 Your Friends 연결 | 막대그래프 |
| 9 | Graphic Organizer | Hard/Easy 빈칸 6개 도식 | p.21 | 빈칸 채우기 | 책에 먼저 쓰기 | 두 기둥 도식 |
| 10 | Details: 누가 맞나? | Mei·Mateo·Mike 발언 카드 3장 | p.21 Details 3문장 | T/F 판단 + 근거 | F·F·T | 인물 카드 3장 |
| 11 | My Turn | "I can change ~. From today, I will ~" 틀 | — | 바꿀 것 문장 쓰기 | 6차시 쓰기 씨앗 | 새싹 그림 |
| 12 | Wrap-up | 조언 문장 재제시 + 다음 차시 예고 | 결론 문장 | 함께 읽기 | — | 일출 배너 |

## 5차시 — 문법·어휘 (12p)

| Slide | 페이지 제목 | 학생에게 보이는 내용 | 교재 원문/예문 | 학생 과제 | Teacher Note | Style Tip |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | 5차시 문법·어휘 | 오늘의 두 미션(who/which + if / 반의어) | — | — | — | 미션 배지 2개 |
| 2 | 본문에서 만난 문장 | 색 표시 문장 2개 | "There is always someone in your family who drives you crazy." / "Robbie bought a backpack which is big and light." | who/which가 꾸미는 명사 찾기 | 화살표 연결 | 문장 카드 2장 |
| 3 | 예문 관찰: who/which | 예문 3개 | "Mr. Parker is a farmer who grows orange trees." / "An orange is a fruit which has a lot of vitamin C." / "There are so many toy birds which look like you." | 공통점 비교 | 규칙 직접 설명 금지 | 농부·오렌지·새 그림 |
| 4 | 규칙 정리 ① | who = 사람 / which = 사물·동물 + 화살표 도식 | p.24 | 규칙 문장 완성 | 학생 발견 후 정리 | 두 갈래 도식 |
| 5 | Practice A | 빈칸 4개(I want to be a friend who ~ / live in a house which ~ / have a pet which ~ / travel to countries which ~) + 예시 | p.24 A | 2개 완성·읽기 | 예시 1개 함께 | 빈칸 카드 4장 |
| 6 | 예문 관찰: if | if 예문 3개 | "If you mix black and white, you will get gray." / "If you visit Bucheon this summer, you will see the Comics Festival." / "If I have two concert tickets, I will go to the concert with my grandpa." | if절·주절 시제 비교 | 두 색 표시 | 물감·축제·콘서트 그림 |
| 7 | 규칙 정리 ② | If + 현재형(조건) → 주어 + will(결과) 도식 | p.24 B | 규칙 필기 | 신호등 규칙 | 조건→결과 화살표 |
| 8 | Practice B | 빈칸 4개(I will go for a walk if ~ / If I see a big spider, I will ~ / If I find a 50,000 won note ~ / I will call my best friend if ~) | p.24 B | 완성·주고받기 | if절 will 금지 점검 | 빈칸 카드 4장 |
| 9 | Words: 반의어 매칭 | 단어 16개 섞인 카드 | p.25 A(difficult-easy, full-hungry, long-short, early-late, light-heavy, slow-fast, boring-interesting, messy-clean) | 8쌍 연결 | 카드 뒤집기 게임 | 카드 격자 |
| 10 | Words: 문장 완성 | 그림 문장 6개 빈칸 | p.25 B(fast, messy, long, heavy, boring, full) | 알맞은 말 골라 완성 | 그림 단서 활용 | 6컷 그림 |
| 11 | My Sentence | "If I ~, I will ~" 틀 + 예시 | — | 자기 문장 1개 쓰기 | 이번 학기 계획 연결 | 펜 카드 |
| 12 | Wrap-up | 오늘의 규칙 2개 + 반의어 8쌍 요약 | — | 규칙 소리 내어 읽기 | 6차시 도전 과제 예고 | 요약 카드 |

## 6차시 — 쓰기 + 단원 마무리 (12p)

| Slide | 페이지 제목 | 학생에게 보이는 내용 | 교재 원문/예문 | 학생 과제 | Teacher Note | Style Tip |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | 6차시 쓰기 + 마무리 | 단원 회고 한마디 질문 | — | 계획과 변화 연결 말하기 | 한국어 허용 | 퍼즐 완성 그림 |
| 2 | Model Text: My Phone Habit | 준모의 글 전체 원문 | p.22 "I want to change my phone habit. I use my phone when I feel bored. … From now on, I will do two things to break the habit. I will turn off my phone after 10 p.m. I will also download a phone control app … If I feel bored, I will talk to my family or read comic books." | 조용히 읽기 | 색 밑줄 준비 | 스마트폰 일러스트 (하이브리드) |
| 3 | 구조 찾기 | 3부 구조 표(바꾸고 싶은 것/이유/할 일) + 색 코드 | p.22 Step 1 표 | 밑줄 긋고 표 채우기 | 이유: It is a waste of time. | 3단 구조 도식 |
| 4 | 언어 지원 상자 | 이동 가능 표현(I want to change ~ / It is a waste of ~ / From now on, I will ~ / If I feel ~, I will ~) | p.22 모범 글에서 추출 | 자기 글에 쓸 표현 고르기 | 도전: if/who 문장 | 도구 상자 그림 |
| 5 | Step 2: Take Notes | 계획 표(바꾸고 싶은 것/이유/할 일 3칸) | p.22 Step 2 | 표 채우기 | 4차시 문장 재사용 | 빈 표 카드 |
| 6 | Step 3: Write | 쓰기 과제(4~6문장) + 마무리 공식 + 도전 과제 | p.22 Step 3 | 초고 쓰기(12분) | 순회·개별 지원 | 타이머 + 펜 |
| 7 | Check & Share | 짝 피드백 체크리스트(3부 구조? will 문장?) + 별표 규칙 | — | 바꿔 읽고 별표 | 점검 2개로 제한 | 체크 카드 2장 |
| 8 | 인생 계획: 나윤이 | 나윤이의 3단계 계획(요리 배우기 → 상하이 식당 → 내 가게) | p.23 | 예시 보고 구조 파악 | 연령대별 2개씩 | 인생 사다리 그림 |
| 9 | Talk about Your Plans | 말하기 틀(In my ~s, I'm planning to ~ / You should ~) + 모범 대화 | p.23 모범 대화(noodle restaurant) | 짝과 계획 이야기 | 조언 표현 재활용 | 대화 말풍선 |
| 10 | Check Yourself | 4영역 자기 점검표(interesting/useful/easy/challenging) | p.26 | challenging 재표시 | 결과 수합 | 자기 점검 카드 |
| 11 | Step Up: 계단 게임 | 게임 규칙(가위바위보→문제 풀기→계단 오르기) | p.26 How to Play | 짝과 게임 | 시간 남으면 | 계단·과자 집 그림 |
| 12 | Wrap-up | "From now on, I will ~" + 단원 완주 축하 | — | 마무리 문장 읽기 | 글 수집 | 트로피 배너 |

---

[PPT 개요 품질 자체 점검]
1. 주요 문제: 없음 — 모든 페이지에 원문/예문/과제/지원 장치 배치, 답 미리 제시 없음
2. 위험 등급: 낮음
3. 수정 제안: 읽기 원문 페이지(3차시 7~9, 4차시 3~5, 6차시 2)는 텍스트가 길어 하이브리드(빈 카드 이미지 + 편집 텍스트)로 제작
4. 교사 발화 대본 생성을 이어서 진행하기를 권장하는가: 아니오 (사용자 미요청)
