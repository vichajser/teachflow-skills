# 단원 차시 분할안 — 중2 영어 Lesson 1 "Off to a Good Start"

**TeachFlow · Lesson Workflow — PHASE 1 산출물**
입력 Sources: 첨부 교재(중2 검정 교과서 Lesson 1, 교과서 p.10~27, PDF 18쪽). 교사용 지도서 미첨부.
가정(명시): 공교육 중학교 2학년, CEFR A1+~A2 가정, 차시당 45분, 총 6차시(교재 기본 구성과 동일). 기관 유형은 공교육 학교로 추정.

---

## 제1부: 단원 내용 점검

| 구성 요소 | 쪽수/위치 | 내용 유형 및 핵심 내용 | 관련 어휘/문법/기능 표현 | 핵심 여부 |
| --- | --- | --- | --- | --- |
| Warm Up / Plan Ahead | p.10 | 주제 활성화(올해 이루고 싶은 목표) + Lesson 자기 진단(Listening/Speaking/Reading/Writing에 interesting/useful/easy/challenging 표시) | 목표 관련 어휘 활성화 | 보조 |
| Get Ready Dialog 1 (Script 1.1) | p.12 | Minsol이 오빠 Minsu에게 보여 준 주간 계획표(Weekly Planner). 계획 이유 묻기 | Why does Minsol plan to make a schedule? / She wants to ___ better. | 핵심(듣기1) |
| Get Ready Dialog 2 (Script 1.2) | p.13 | 아기 돼지·늑대 그림 연계 충고 대화. +Question: What advice does Minsu give to Minsol? | You should ... / Why don't you ...? | 핵심(듣기1) |
| All Ears (Script 1.3) | p.13 | 강세·억양 듣고 따라 하기 | How would you achieve your goal? / I'd like to visit you this Saturday. | 보조(발음) |
| Listen More (Script 1.4) | p.13 | 종하가 할머니께 전화 — 만화 보고 이유 추측 → 듣고 토요일 할 일 완성(visit Grandma, plant some ___) → 다시 듣고 준비물 고르기 | 계획 말하기 듣기 이해 | 핵심(듣기2) |
| 말하기 1 "I'm Planning to Play a Trick" | p.14 | 특정 날짜(April Fool's Day, Parents' Day, 생일, 이번 주말)의 계획 묻고 답하기 + RapTime | What are you planning to do on ~? / I'm planning to ~ | 핵심(말하기1) |
| 말하기 2 "Why Don't You Take Your Baseball Glove?" | p.15 | 소망·계획을 듣고 충고하는 그룹 대화 + 랩 | Why don't you ~? / I think you should ~ | 핵심(말하기2) |
| My Speaking Portfolio (Script 1.5) | p.16 | Step 1 인물별 올해 목표·계획 듣고 연결(Nayeon/Junho/Hojin) → Step 2 자기 목표·실행 계획 세우기 → Step 3 발표 | I have two goals for the year. First, I'd like to finish a 10 km marathon. To achieve this goal, I'm planning to run for an hour every day. | 핵심(말하기 산출) |
| Before You Read | p.17 | Topic(올해 바꾸고 싶은 것) + Question Box(글의 대상·목적, 큰제목·소제목 예측, Robbie가 산 배낭 문장) + Expressions(그림 보고 의미 추측) | messy, clean up, drive me crazy, care for each other; Robbie bought a backpack which is big and light. | 핵심(읽기 전) |
| 본문 도입 | p.18 | Teen Today가 웹툰 작가 Raccoon 97에게 새 학년 조언을 요청한 글 | Beginning a new school year is stressful to many students. / get off to a good start | 핵심 |
| 본문 1부 "Things That Are Hard to Change" | p.19 | Your Messy Room / Your Family / Your Name on Your Teacher's List. 작가작업실의 고양이(Sartre: "Life is C between B and D" = Choice between Birth and Death). Q1(T/F) | hard to change 구조, 빈도·인과 부사 표현 | 핵심 |
| 본문 2부 "Things That Are Easy to Change" + Top Plans for the Year | p.20 | Your Underpants / Your Friends / Your Mind + Teen Today 독자 200명 설문 막대그래프(make new friends 72, read more books 41, get better grades 28, spend less time online 26, learn useful skills 19, other 14). Q2(choose). 마무리 메시지: Focus on the things that are easy to change, and try to make today better than yesterday. | easy to change 구조, if절("If you can change your mind, you can change your life.") | 핵심 |
| After You Read | p.21 | Graphic Organizer(Hard/Easy 각 3항목 빈칸) + Details(Mei·Mateo·Mike 발화의 사실 판단) + Share(의견 말하기) | 본문 재구성 | 핵심 |
| My Writing Portfolio "A Good Time for Change" | p.22 | 모범 글 "My Phone Habit" 읽고 정리(바꾸고 싶은 것/이유/할 일) → 메모 → 쓰고 짝과 비교 | I want to change ... / From now on, I will ... | 핵심(쓰기) |
| 인생 계획 말하기 | p.23 | Nayun의 인생 계획(in high school / in my 20s / in my 30s) 참고해 자기 인생 계획 2개씩 세우고 조언 주고받기 | I'm planning to ~ in my 30s. / What should I do? / You should ~ first. | 보조(말하기 확장) |
| 문법 (p.24) | p.24 | A: who/which 관계절(Mr. Parker is a farmer who grows orange trees. / An orange is a fruit which has a lot of vitamin C. / There are so many toy birds which look like you.) I want to be a friend who ___ 등 4문장 말하기. B: if 조건문(If you mix black and white, you will get gray. / If you visit Bucheon this summer, you will see the Comics Festival.) If I see a big spider, I will ___ 등 4문장 | who, which가 이끄는 절이 명사를 뒤에서 꾸밈 / if절은 조건 | 핵심(문법) |
| 어휘 (p.25) | p.25 | 반의어 연결( difficult-easy, full-hungry, long-short, early-late, light-heavy, slow-fast, boring-interesting, messy-clean ) + 그림 보고 문장 완성 6문항 | 반의어 쌍 | 보조(어휘) |
| Check Yourself / Step Up | p.26 | Lesson 자기 점검(challenging 재표시) + 계단 오르기 말하기 게임(1~10번 문제) | 단원 전체 복습 | 보조(정리) |
| 마무리 평가 페이지 | p.27 | Words & Expressions(keep the change, drive slowly, drive me crazy), Listening(Script 1.6·1.7: Mina의 여수 계획, Yunsu에게 충고), Speaking, Reading(Minsol의 주말 downtime 계획 — 셋째 주 토요일 무료 콘서트, 제목 완성 "Minsol's ___ Plans"), Grammar & Writing(who/which/if 빈칸) | 단원 종합 확인 | 보조(평가·복습) |

## 제2부: 단원 중점 판단

1. **반드시 중점적으로 가르쳐야 할 내용**
   - 기능 표현 2축: 계획·의도 말하기(What are you planning to do? / I'm planning to ~ / I'd like to ~ / I'm going to ~)와 충고하기(Why don't you ~? / I think you should ~). 이 단원의 의사소통 목표이며 듣기·말하기·쓰기 전 영역에 반복 등장한다.
   - 읽기 본문 "Beginning a New School Year": Hard/Easy to Change의 대비 구조와 글의 최종 메시지. 설문 그래프 읽기 포함.
   - 문법: who/which 관계절과 if 조건문 — 중2 핵심 문법 항목이자 내신 지필평가 직결 항목.
2. **이해하고 연습해야 할 내용**
   - Expressions(messy, clean up, drive me crazy, care for)와 반의어 쌍: 읽기·쓰기의 이해를 돕는 도구.
   - My Speaking/Writing Portfolio: 단원 산출 과제. 모범 문장·모범 글의 구조 분석이 필요하다.
3. **가볍게 처리하거나 통합 처리할 내용**
   - Plan Ahead / Check Yourself: 차시 시작과 마무리의 자기 진단으로 1~2분씩 통합 처리.
   - All Ears(억양): 듣기 차시 안에 3차 듣기 언어 집중으로 통합.
   - Step Up 게임과 p.27 종합 확인: 마지막 차시의 정리·복습 활동으로 통합.
   - RapTime/랩: 말하기 차시의 워밍업 챈트로 통합.

평가 연계: who/which 관계절과 if 조건문, 반의어, 기능 표현은 중2 내신 지필평가의 단골 영역. 수행평가로는 My Writing Portfolio 글쓰기와 인생 계획 발표가 연결 가능.
2022 개정 교육과정 성취기준: 영어과 듣기·말하기·읽기·쓰기 영역과 연계 — **성취기준 코드는 교사 확인 필요**.

## 제3부: 단원 차시 분할안

| 차시 | 주 수업 유형 | 보조 수업 유형 | 핵심 자료 | 핵심 언어 항목 | 기능 중점 | 이 차시의 단계별 산출물 | 분할 근거 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 듣기 수업 | 어휘 활성화, 발음(억양) | Warm Up/Plan Ahead(p.10), Dialog 1·2(Script 1.1·1.2), All Ears(1.3), Listen More(1.4) (p.12~13) | I'm planning to ~ / You should ~ / Why don't you ~? (듣기 이해 수준) | 계획·충고 대화의 주제와 세부 정보 듣기 | 주간 계획표 정보 완성 + 종하의 토요일 할 일 완성 | 단원 도입과 최초 언어 입력은 듣기로. 대본 없이 듣는 경험을 보호하기 위해 말하기 산출 전에 배치 |
| 2 | 말하기 수업 | 듣기 확인(Portfolio Step 1) | 말하기 1·2(p.14~15), RapTime, My Speaking Portfolio(p.16) | What are you planning to do ~? / I'm planning to ~ / Why don't you ~? / I think you should ~ | 계획 묻고 답하기 + 소망 듣고 충고하기 | 짝 대화 완성 + "My Goals for the Year" 발표문 | 1차시에 들은 표현을 구두 산출로 전환. Portfolio가 차시 최종 산출물 |
| 3 | 읽기 수업 | 읽기 전 장애 어휘 | Before You Read(p.17), 본문 도입+1부(p.18~19) | messy, clean up, drive me crazy, care for; hard to change | 예측 → 1부 요지·세부 읽기 | 예측 문장 + 1부 정보 정리(Hard to Change 3항목) | 읽기 전략(예측)과 1부 이해에 집중. 어휘는 읽기 전 4개만 처리 |
| 4 | 읽기 수업 | 담화 분석(대비 구조), 말하기 전이(Share) | 본문 2부+설문 그래프(p.20), After You Read(p.21) | easy to change; if절 인용문; 수치 읽기 | 2부 읽기 + 전체 대비 구조 재구성 | 완성된 Graphic Organizer + Details 판단 근거 + 의견 한 문장 | 1부와 대비되는 2부를 읽고 전체 구조를 조직하는 데 한 차시 |
| 5 | 문법 수업 | 어휘(반의어) | 문법 p.24(who/which, if), 어휘 p.25(반의어) | who/which 관계절, if 조건문 | 형태 발견 → 규칙 귀납 → 맥락 사용 | who/which·if를 사용한 자기 문장 4개 + 반의어 완성 | 본문에 이미 노출된 두 문법을 모아 발견 학습. 반의어는 어휘 망 확장으로 종속 처리 |
| 6 | 쓰기 수업 | 말하기 전이(인생 계획), 통합 정리 | My Writing Portfolio(p.22), 인생 계획(p.23), Check Yourself/Step Up(p.26), p.27 종합 확인 | I want to change ~ / From now on, I will ~ / if·관계절 활용 | 모범 글 분석 → 계획 → 초고 → 공유 | "내가 바꾸고 싶은 것" 글 1편 + 단원 자기 점검 완료 | 단원 통합 산출. 쓰기가 단원 주제(변화·계획)를 수렴하고, 정리 게임으로 마무리 |

## 제4부: 분할 논리 설명

1. **전체 학습 핵심 흐름**: "계획·충고 표현 입력(듣기) → 구두 연습과 발표(말하기) → 변화의 대상에 대한 읽기(1부·2부) → 언어 형식 정리(문법·어휘) → 자기 변화 계획 글쓰기와 단원 정리(쓰기·통합)". 입력에서 산출로, 언어에서 의미로, 의미에서 자기 표현으로 나아간다.
2. **차시 순서 배치 근거**: 교재 기본 순서(듣기→말하기→읽기→쓰기)를 따르되, 문법·어휘를 읽기 뒤에 배치한 이유는 두 문법 항목(who/which, if)이 본문에 먼저 노출되므로 읽기에서 의미를 만난 뒤 5차시에 형태를 정리하는 발견 학습 경로가 자연스럽기 때문이다.
3. **통합 처리한 내용**: Plan Ahead/Check Yourself(1·6차시 자기 진단), All Ears(1차시 3차 듣기 언어 집중), RapTime(2차시 워밍업), Step Up 게임과 p.27(6차시 정리·복습), 인생 계획 말하기 p.23(6차시 쓰기 전 아이디어 확장 — 계획 표현의 재사용).
4. **독립 차시로 만든 내용**: 문법(who/which + if)은 내신 직결 핵심 항목이므로 독립 차시를 유지하되 반의어를 종속시켜 한 차시에 합리적으로 담았다.
5. **차시가 줄어들 때**: p.27 종합 확인을 과제로 돌리고 6차시를 쓰기+정리로 압축 가능. 인생 계획(p.23)을 삭제하면 6차시에 쓰기 시간을 더 확보할 수 있다.
6. **차시가 늘어날 때**: 읽기를 3차시로 확장(본문 정독+다시 말하기에 별도 시간), Portfolio 발표를 별도 수행평가 차시로 확장 가능.
7. **어휘·문법과 기능별 수업 유형의 관계**: Expressions 4개는 3차시 읽기 전 장애 어휘로, 반의어는 5차시 어휘 망으로, W&E(keep the change 등)는 6차시 p.27 확인으로 처리해 어휘가 읽기 흐름을 가로채지 않게 했다. who/which는 3차시 Question Box 문장(Robbie bought a backpack which ...)에서 의미로 먼저 만나고 5차시에 형태를 정리한다.
8. **마지막 차시의 통합 산출**: 6차시는 모범 글 "My Phone Habit"의 구조(바꾸고 싶은 것→이유→할 일)를 분석한 뒤, 단원의 목표 표현(계획: I'm going to/I will, 조건: if, 수식: who/which)을 사용해 자기 변화 계획 글을 완성하고 짝과 비교·공유한다. Check Yourself와 Step Up 게임으로 단원을 회수한다.

---

*다음 단계: 이 분할안을 바탕으로 차시 수업 설계안(PHASE 2)을 생성한다.*
